
<?php $__env->startSection('title'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page'); ?>
    <section class="py-5">
        <div class="container">
            <div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <div class="col-md-4 mb-3">
                        <div class="card" style="width: 18rem;">
                            <img src="<?php echo e(asset('/')); ?><?php echo e($product->image); ?>" class="card-img-top" alt="product-image" height="250px">
                            <div class="card-body">
                              <h5 class="card-title"><?php echo e($product->name); ?></h5>
                              <p class="card-text"><?php echo e($product->description); ?></p>
                              <a href="#" class="btn btn-primary">Buy Now</a>
                            </div>
                          </div>
                      </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\php Laravel\arif xammp\htdocs\laravel all\assessment-2\resources\views/frontend/home/index.blade.php ENDPATH**/ ?>