<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use Illuminate\Http\Request;

class AddProductController extends Controller
{    
    public static $path = '/product-image';
     function create()
    {
        return view('backend.product.add');
    }

    function store(Request $r)
    {
        $imgName ='pp/'. time().'.'.$r->image->getClientOriginalExtension();
        $r->image->move(public_path(self::$path), $imgName);

        $product = new Assessment();

        $product->name             = $r->name;
        $product->category         = $r->category;
        $product->brand            = $r->brand;
        $product->description      = $r->description;
        $product->image            = self::$path. $imgName;
        $product->save();

        return back()->with('natification', 'Product Add Succesfully');           
    }
}
