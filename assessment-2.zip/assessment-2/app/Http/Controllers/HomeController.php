<?php

namespace App\Http\Controllers;

use App\Models\Assessment;
use Illuminate\Http\Request;

class HomeController extends Controller
{
    function index()
    {
        
       return view('frontend.home.index',['products'=>Assessment::all()]);
    }
}
