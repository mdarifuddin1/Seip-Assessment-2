<?php

use App\Http\Controllers\AddProductController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Route;

Route::get('/',[HomeController::class,'index'])->name('home');
Route::get('/create-product',[AddProductController::class,'create'])->name('create-product');
Route::post('/add-product',[AddProductController::class,'store'])->name('store-product');