@extends('master')
@section('title')
    Home
@endsection

@section('page')
    <section class="py-5">
        <div class="container">
            <div class="row">
                @foreach ($products as $product)
                      <div class="col-md-4 mb-3">
                        <div class="card" style="width: 18rem;">
                            <img src="{{asset('/')}}{{ $product->image }}" class="card-img-top" alt="product-image" height="250px">
                            <div class="card-body">
                              <h5 class="card-title">{{$product->name}}</h5>
                              <p class="card-text">{{$product->description}}</p>
                              <a href="#" class="btn btn-primary">Buy Now</a>
                            </div>
                          </div>
                      </div>
                    @endforeach
            </div>
        </div>
    </section>
@endsection