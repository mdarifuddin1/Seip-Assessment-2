@extends('master')
@section('title')
    Add-Product
@endsection

@section('page')
    <section class="py-3">
        <div class="container">
            <div class="row">
                <div class="col-md-8 offset-2">
                    <h1 class="text-center">Add Product</h1>
                    
                    <div class="alert alert-warning alert-dismissible fade show" role="alert">
                        {{Session::get('natification')}}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                      </div>
                   
                    <form class="p-5 bg-secondary rounded" method="POST" action="{{route('store-product')}}" enctype="multipart/form-data">
                        @csrf
                        <div class="mb-3">
                          <label class="form-label">Product Name</label>
                          <input type="text" class="form-control" name="name">
                          
                        <div class="mb-3">
                          <label class="form-label">Product Category</label>
                          <input type="text" class="form-control" name="category">
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Brand</label>
                            <input type="text" class="form-control" name="brand">
                          </div>

                        <div class="mb-3">
                            <label class="form-label">Product Description</label>
                            <textarea name="description" id="" cols="85" rows="3"></textarea>
                        </div>

                        <div class="mb-3">
                            <label class="form-label">Product Image</label>
                            <input type="file" class="form-control" name="image" accept="image/*">
                        </div>
                       
                        <button type="submit" class="btn btn-primary">Add Product</button>
                      </form>
                </div>
            </div>
        </div>
    </section>
@endsection
